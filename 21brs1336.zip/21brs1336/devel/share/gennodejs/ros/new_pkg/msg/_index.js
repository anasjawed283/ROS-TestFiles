
"use strict";

let samplemsg = require('./samplemsg.js');

module.exports = {
  samplemsg: samplemsg,
};
