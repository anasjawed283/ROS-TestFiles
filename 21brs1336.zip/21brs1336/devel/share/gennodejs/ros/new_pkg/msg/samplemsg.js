// Auto-generated. Do not edit!

// (in-package new_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class samplemsg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.marks = null;
      this.pf = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('marks')) {
        this.marks = initObj.marks
      }
      else {
        this.marks = 0.0;
      }
      if (initObj.hasOwnProperty('pf')) {
        this.pf = initObj.pf
      }
      else {
        this.pf = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type samplemsg
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [marks]
    bufferOffset = _serializer.float32(obj.marks, buffer, bufferOffset);
    // Serialize message field [pf]
    bufferOffset = _serializer.bool(obj.pf, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type samplemsg
    let len;
    let data = new samplemsg(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [marks]
    data.marks = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pf]
    data.pf = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'new_pkg/samplemsg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '084c099de67a887ab81e9ab62dc95fd3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 id
    string name
    float32 marks
    bool pf
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new samplemsg(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.marks !== undefined) {
      resolved.marks = msg.marks;
    }
    else {
      resolved.marks = 0.0
    }

    if (msg.pf !== undefined) {
      resolved.pf = msg.pf;
    }
    else {
      resolved.pf = false
    }

    return resolved;
    }
};

module.exports = samplemsg;
